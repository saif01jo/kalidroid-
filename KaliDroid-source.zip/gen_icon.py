#!/usr/bin/env python3
"""KaliDroid launcher icon generator.

Draws a glossy green padlock on a dark navy tile: vertical tile gradient, green
bloom behind the lock, metallic shackle, bevel, keyhole, green rim glow, drop
shadow and vignette.

Writes every mipmap density used by the app:

    ic_launcher.png             legacy square (adaptive fallback < API 26)
    ic_launcher_round.png       legacy round
    ic_launcher_foreground.png  adaptive foreground (full-bleed tile)
    ic_launcher_monochrome.png  themed-icon layer (white lock only)

and, with --master, a 4096x4096 PNG for the repository/social preview.

usage: gen_icon.py <res_dir> [--preview DIR] [--master PATH] [--size N]

Requires Pillow (pip install pillow).
"""
from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter

HERE = Path(__file__).resolve().parent
DEFAULT_MASTER = HERE / "icon" / "kalidroid-icon-4096.png"

TILE_TOP = (13, 18, 32)        # tile gradient, top
TILE_BOTTOM = (3, 4, 9)        # tile gradient, bottom
GREEN_GLOW = (0, 200, 115)     # bloom behind the lock
BODY_TOP = (150, 255, 196)     # lock body gradient, top
BODY_BOTTOM = (0, 145, 78)     # lock body gradient, bottom
SHACKLE_TOP = (175, 255, 215)  # metallic shackle, top
SHACKLE_BOTTOM = (0, 120, 70)  # metallic shackle, bottom
KEYHOLE = (3, 22, 14)          # keyhole (near-black green)
MONO_RGB = (247, 251, 255)     # monochrome layer

CORNER = 0.225                 # rounded-square radius / size
SS = 4                         # supersampling factor

LEGACY_SIZES = {"ldpi": 36, "mdpi": 48, "hdpi": 72, "xhdpi": 96,
                "xxhdpi": 144, "xxxhdpi": 192}
FG_SIZES = {"mdpi": 108, "hdpi": 162, "xhdpi": 216, "xxhdpi": 324,
            "xxxhdpi": 432}

# lock geometry, as fractions of the icon size
BODY_W, BODY_H = 0.56, 0.40
BODY_CY = 0.60
BODY_R = 0.062
SHACKLE_R, SHACKLE_STROKE = 0.185, 0.078
KEYHOLE_R = 0.052

# the adaptive layer is 108dp but only its central 72dp circle is visible
FG_ZOOM = 72.0 / 108.0


def lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def vgradient(size: int, top, bottom) -> Image.Image:
    col = Image.new("RGB", (1, 256))
    px = col.load()
    for y in range(256):
        px[0, y] = lerp(top, bottom, y / 255.0)
    return col.resize((size, size), Image.BILINEAR)


def radial(size: int, inner, outer, alpha_gain: float = 1.0) -> Image.Image:
    s = 256
    g = Image.radial_gradient("L").resize((s, s), Image.BILINEAR)
    img = Image.composite(Image.new("RGB", (s, s), inner),
                          Image.new("RGB", (s, s), outer), g)
    img = img.convert("RGBA")
    img.putalpha(ImageChops.invert(g).point(lambda v: int(v * alpha_gain)))
    return img.resize((size, size), Image.BICUBIC)


def rounded_mask(size: int, radius_frac: float = CORNER, ss: int = 4) -> Image.Image:
    m = Image.new("L", (size * ss, size * ss), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, size * ss - 1, size * ss - 1),
                                        radius=int(size * radius_frac) * ss, fill=255)
    return m.resize((size, size), Image.LANCZOS)


def _shackle_arc(n: int, zoom: float, bw: int, by: int):
    sr = int(n * SHACKLE_R * zoom)
    st = int(n * SHACKLE_STROKE * zoom)
    cx = n // 2
    cy = by - int(n * 0.012 * zoom)
    return (cx - sr, cy - sr, cx + sr, cy + sr), st


def draw_icon(size: int, shape: str = "square", mono: bool = False,
              zoom: float = 1.0, build_master: bool = False) -> Image.Image:
    """Render the icon at `size` px. `shape` is square, circle or none."""
    ss = SS if size <= 512 else 1     # big renders cannot afford 4x memory
    n = size * ss
    tile = vgradient(n, TILE_TOP, TILE_BOTTOM).convert("RGBA")

    # green bloom behind the lock
    b = radial(int(n * 0.80 * zoom), GREEN_GLOW, (5, 9, 18), 0.55)
    tile.alpha_composite(b, ((n - b.size[0]) // 2, (n - b.size[1]) // 2))

    # vignette so the corners fall away
    v = Image.radial_gradient("L").resize((n, n), Image.BILINEAR)
    vig = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    vig.putalpha(v.point(lambda x: int(x * 0.50)))
    tile = Image.alpha_composite(tile, vig)

    bw = int(n * BODY_W * zoom)
    bh = int(n * BODY_H * zoom)
    bx = (n - bw) // 2
    by = int(n * BODY_CY * zoom - bh / 2) + int(n * (1 - zoom) * 0.5)
    r = int(n * BODY_R * zoom)
    arc, st = _shackle_arc(n, zoom, bw, by)
    kr = int(n * KEYHOLE_R * zoom)
    kcx = n // 2
    kcy = by + int(bh * 0.40)

    if mono:
        m = Image.new("L", (n, n), 0)
        d = ImageDraw.Draw(m)
        d.arc(arc, 180, 360, fill=255, width=st)
        d.rounded_rectangle((bx, by, bx + bw, by + bh), radius=r, fill=255)
        d.ellipse((kcx - kr, kcy - kr, kcx + kr, kcy + kr), fill=0)
        d.polygon([(kcx - int(kr * 0.55), kcy), (kcx + int(kr * 0.55), kcy),
                   (kcx + int(kr * 0.95), kcy + int(bh * 0.32)),
                   (kcx - int(kr * 0.95), kcy + int(bh * 0.32))], fill=0)
        out = Image.new("RGBA", (n, n), MONO_RGB + (0,))
        out.putalpha(m)
        return out.resize((size, size), Image.LANCZOS)

    # soft green halo around the lock
    sil = Image.new("L", (n, n), 0)
    d = ImageDraw.Draw(sil)
    d.rounded_rectangle((bx, by, bx + bw, by + bh), radius=r, fill=255)
    d.arc(arc, 180, 360, fill=255, width=st)
    halo = sil.filter(ImageFilter.GaussianBlur(n * 0.035)).point(lambda x: int(x * 0.55))
    tile = Image.alpha_composite(
        tile, Image.composite(Image.new("RGBA", (n, n), GREEN_GLOW + (255,)),
                              Image.new("RGBA", (n, n), (0, 0, 0, 0)), halo))

    # drop shadow
    sh = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    d = ImageDraw.Draw(sh)
    d.rounded_rectangle((bx + int(n * 0.008 * zoom), by + int(n * 0.026 * zoom),
                         bx + bw + int(n * 0.008 * zoom), by + bh + int(n * 0.026 * zoom)),
                        radius=r, fill=(0, 0, 0, 200))
    tile = Image.alpha_composite(tile, sh.filter(ImageFilter.GaussianBlur(n * 0.020)))

    # metallic shackle
    smask = Image.new("L", (n, n), 0)
    ImageDraw.Draw(smask).arc(arc, 180, 360, fill=255, width=st)
    grad = vgradient(n, SHACKLE_TOP, SHACKLE_BOTTOM).convert("RGBA")
    tile.alpha_composite(Image.composite(grad, Image.new("RGBA", (n, n), (0, 0, 0, 0)), smask))

    # lock body
    body = vgradient(bw, BODY_TOP, BODY_BOTTOM).resize((bw, bh), Image.BILINEAR).convert("RGBA")
    m = Image.new("L", (bw * 4, bh * 4), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, bw * 4 - 1, bh * 4 - 1), radius=r * 4, fill=255)
    body.putalpha(m.resize((bw, bh), Image.LANCZOS))
    tile.alpha_composite(body, (bx, by))

    # bevel on the body edge
    bev = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    ImageDraw.Draw(bev).rounded_rectangle((bx, by, bx + bw, by + bh), radius=r,
                                          outline=(210, 255, 230, 110),
                                          width=max(1, int(n * 0.005 * zoom)))
    tile = Image.alpha_composite(tile, bev.filter(ImageFilter.GaussianBlur(n * 0.003)))

    # keyhole
    kh = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    d = ImageDraw.Draw(kh)
    d.ellipse((kcx - kr, kcy - kr, kcx + kr, kcy + kr), fill=KEYHOLE + (255,))
    d.polygon([(kcx - int(kr * 0.55), kcy), (kcx + int(kr * 0.55), kcy),
               (kcx + int(kr * 0.95), kcy + int(bh * 0.32)),
               (kcx - int(kr * 0.95), kcy + int(bh * 0.32))], fill=KEYHOLE + (255,))
    tile = Image.alpha_composite(tile, kh.filter(ImageFilter.GaussianBlur(n * 0.0015)))

    # specular sweep across the top of the body
    sp = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    ImageDraw.Draw(sp).rounded_rectangle(
        (bx + int(bw * 0.05), by + int(bh * 0.06), bx + int(bw * 0.95), by + int(bh * 0.42)),
        radius=int(r * 0.8), fill=(255, 255, 255, 40))
    tile = Image.alpha_composite(tile, sp.filter(ImageFilter.GaussianBlur(n * 0.008)))

    if build_master:
        return tile.resize((size, size), Image.LANCZOS)

    # rim light along the tile edge (invisible once the launcher masks the layer)
    rim = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    inset = max(1, int(n * 0.006))
    ImageDraw.Draw(rim).rounded_rectangle(
        (inset, inset, n - 1 - inset, n - 1 - inset),
        radius=max(1, int(n * CORNER) - inset),
        outline=(110, 240, 180, 70), width=max(1, int(n * 0.004)))
    tile = Image.alpha_composite(tile, rim)

    tile = tile.resize((size, size), Image.LANCZOS)
    if shape == "none":
        return tile
    out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    if shape == "circle":
        mask = Image.new("L", (size * 4, size * 4), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, size * 4 - 1, size * 4 - 1), fill=255)
        mask = mask.resize((size, size), Image.LANCZOS)
    else:
        mask = rounded_mask(size)
    out.paste(tile, (0, 0), mask)
    return out


def previews(pdir: Path) -> None:
    pdir.mkdir(parents=True, exist_ok=True)
    for s in (432, 192, 96, 48):
        draw_icon(s).save(pdir / f"icon-{s}.png")
    draw_icon(192, "circle").save(pdir / "icon-round-192.png")
    draw_icon(432, "none", zoom=FG_ZOOM).save(pdir / "layer-432.png")

    sheet = Image.new("RGB", (760, 250), (240, 240, 244))
    x = 24
    for s in (192, 96, 48):
        im = Image.open(pdir / f"icon-{s}.png").convert("RGBA")
        sheet.paste(im, (x, 30), im)
        x += s + 34
    sheet.save(pdir / "sheet.png")


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    opts = {}
    for i, a in enumerate(sys.argv):
        if a.startswith("--") and i + 1 < len(sys.argv):
            opts[a] = sys.argv[i + 1]

    res = Path(args[0]) if args else Path("res")

    for name, px in LEGACY_SIZES.items():
        d = res / f"mipmap-{name}"
        d.mkdir(parents=True, exist_ok=True)
        draw_icon(px).save(d / "ic_launcher.png")
        draw_icon(px, "circle").save(d / "ic_launcher_round.png")

    for name, px in FG_SIZES.items():
        d = res / f"mipmap-{name}"
        d.mkdir(parents=True, exist_ok=True)
        draw_icon(px, "none", zoom=FG_ZOOM).save(d / "ic_launcher_foreground.png")
        draw_icon(px, "none", mono=True, zoom=FG_ZOOM).save(d / "ic_launcher_monochrome.png")

    if "--master" in opts:
        dest = Path(opts["--master"])
        dest.parent.mkdir(parents=True, exist_ok=True)
        px = int(opts.get("--size", 4096))
        master = draw_icon(px, "none", build_master=True)
        # drawn without supersampling at this size; a sub-pixel blur removes the
        # stair-stepping on the arc and the rounded corners
        master = master.filter(ImageFilter.GaussianBlur(max(0.6, px / 4096 * 0.8)))
        master.save(dest)
        print("master:", dest, master.size)

    if "--preview" in opts:
        previews(Path(opts["--preview"]))
        print("preview:", opts["--preview"])

    print("icons written to", res)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
